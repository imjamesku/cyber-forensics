#!/bin/sh

# create a folder for src and copy files
mkdir ./src/lib/Transforms/MyLLVMPass
cp ./MyLLVMPass/CMakeLists.txt ./src/lib/Transforms/MyLLVMPass/
cp ./MyLLVMPass/Makefile ./src/lib/Transforms/MyLLVMPass/
cp ./MyLLVMPass/MyLLVMPass.cpp ./src/lib/Transforms/MyLLVMPass/
cp ./MyLLVMPass/MyLLVMPass.exports ./src/lib/Transforms/MyLLVMPass/



# backup the makefile
timestamp=$(date +%s)
cp ./build/lib/Transforms/Makefile ./build/lib/Transforms/Makefile.backup.$timestamp

# add project folder into the makefile
sed -i 's|PARALLEL_DIRS = Utils Instrumentation Scalar InstCombine IPO Vectorize Hello ObjCARC|PARALLEL_DIRS = Utils Instrumentation Scalar InstCombine IPO Vectorize Hello  ObjCARC MyLLVMPass|g' ./build/lib/Transforms/Makefile

# create a folder for build and copy files
mkdir ./build/lib/Transforms/MyLLVMPass
cp ./MyLLVMPass/Makefile.build ./build/lib/Transforms/MyLLVMPass/Makefile

