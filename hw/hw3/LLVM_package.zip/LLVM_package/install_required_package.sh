sudo apt-get install build-essential 
sudo apt-get install python
