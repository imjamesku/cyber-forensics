/* hpath.c - the central highscore file location
 *
 * Copyright 1999  Jochen Voss  */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "moon-buggy.h"


const char *score_dir = SCORE_DIR;
